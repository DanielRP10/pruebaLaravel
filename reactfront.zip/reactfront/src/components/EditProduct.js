import React, {useEffect, useState} from 'react'
import axios from 'axios'
import { useNavigate, useParams } from 'react-router-dom'

const endpoint = 'http://localhost:8000/api/product'

function EditProduct() {
    const {id} = useParams()
    const [descripcion, setDescripcion] = useState('')
    const [precio, setPrecio] = useState(0)
    const [stock, setStock] = useState(0)
    const navigate = useNavigate()
    const updateProduct = async (e) => {
        e.preventDefault()
        await axios.put(`${endpoint}/${id}`, { descripcion, precio, stock })
        navigate('/')
    }
    useEffect(() => {
        const getProductById = async () => {
            const response = await axios.get(`${endpoint}/${id}`)
            setDescripcion(response.data.descripcion)
            setPrecio(response.data.precio)
            setStock(response.data.stock)
        }
        getProductById()
    }, [id])
  return (
    <div className='container'>
        <h3>Editar producto</h3>
        <form onSubmit={updateProduct}>
            <div className='form-group'>
                <label>Descripción:</label>
                <input
                    type="text"
                    className='form-control'
                    value={descripcion}
                    onChange={(e) => setDescripcion(e.target.value)}
                />
            </div>
            <div className='form-group'>
                <label>Precio:</label>
                <input
                    type="number"
                    className='form-control'
                    value={precio}
                    onChange={(e) => setPrecio(parseFloat(e.target.value))}
                />
            </div>
            <div className='form-group'>
                <label>Stock:</label>
                <input
                    type="number"
                    className='form-control'
                    value={stock}
                    onChange={(e) => setStock(parseInt(e.target.value))}
                />
            </div>
            <button type="submit" className='btn btn-primary'>
                Actualizar
            </button>
            <button onClick={() => navigate('/')} className='btn btn-secondary ml-2'>
                Cancelar
            </button>
        </form>
    </div>
  )
}

export default EditProduct
