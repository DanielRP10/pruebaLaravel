import React, {useState} from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const endpoint = 'http://localhost:8000/api/product'

function CreateProduct() {
  const [descripcion, setDescripcion] = useState('')
  const [precio, setPrecio] = useState(0)
  const [stock, setStock] = useState(0)
  const navigate = useNavigate()

  const storeProduct = async (e) => {
    e.preventDefault()
    await axios.post(`${endpoint}`, { descripcion, precio, stock })
    navigate('/')
  }

  return (
    <div className='container'>
        <h3>Crear nuevo producto</h3>
        <form onSubmit={storeProduct}>
            <div className='form-group'>
                <label>Descripción</label>
                <input
                    type='text'
                    className='form-control'
                    value={descripcion}
                    onChange={(e) => setDescripcion(e.target.value)}
                />
            </div>
            <div className='form-group'>
                <label>Precio</label>
                <input
                    type='number'
                    className='form-control'
                    value={precio}
                    onChange={(e) => setPrecio(parseFloat(e.target.value))}
                />
            </div>
            <div className='form-group'>
                <label>Stock</label>
                <input
                    type='number'
                    className='form-control'
                    value={stock}
                    onChange={(e) => setStock(parseInt(e.target.value))}
                />
            </div>
            <button type='submit' className='btn btn-primary'>
                Guardar
            </button>
            <button onClick={() => navigate('/')} className='btn btn-secondary ml-2'>
                Cancelar
            </button>
        </form>
    </div>
  )
}

export default CreateProduct
